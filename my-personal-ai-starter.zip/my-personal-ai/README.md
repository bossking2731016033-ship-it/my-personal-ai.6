# My Personal AI

A free-first Android Java starter project for a personal AI assistant.

## Current status
- Android chat interface prototype
- GitHub Actions workflow to build a debug APK
- The AI model connection is intentionally not included yet; it will be added in a later step using a secure backend so API keys are not placed in the APK.

## Build
Open the repository's **Actions** tab and run **Build Android APK**, or push a commit to `main`. When the workflow succeeds, open the run and download the `my-personal-ai-debug-apk` artifact.
